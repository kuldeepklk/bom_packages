<?php

require __DIR__ . '/utilphp/util.php';
/** util.php library is in vendor
 * Globally namespaced version of the class.
 *
 * @author Brandon Wamboldt <brandon.wamboldt@gmail.com>
 */
class util extends \utilphp\util { }
