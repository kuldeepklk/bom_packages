# Debug Handler
Add support for PHP Debug Bar to make it easier for debugging within awesome enterprise
