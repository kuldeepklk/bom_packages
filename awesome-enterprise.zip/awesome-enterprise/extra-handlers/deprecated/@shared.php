<?php
namespace aw2\active_shared;

\aw2_library::add_service('@shared','Handles the active shared',['env_key'=>'@shared']);



